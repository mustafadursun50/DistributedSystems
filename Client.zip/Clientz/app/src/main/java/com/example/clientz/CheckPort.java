package com.example.clientz;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.SystemClock;
import android.util.Log;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class CheckPort extends MainActivity implements Runnable {

    static String state = "no port";

    public void sendMulticastMessageToGetPort(){
        int mcPort = 4446;
        String mcIPStr = "230.0.0.0";
        DatagramSocket udpSocket = null;
        try {
            udpSocket = new DatagramSocket();
            InetAddress mcIPAddress = InetAddress.getByName(mcIPStr);
            byte[] msg = "hallo".getBytes();
            DatagramPacket packet = new DatagramPacket(msg, msg.length);
            packet.setAddress(mcIPAddress);
            packet.setPort(mcPort);
            udpSocket.send(packet);
            System.out.println("Sent a  multicast message.");
            udpSocket.close();
        } catch (SocketException | UnknownHostException e) {
            System.out.println("NO PORT1");

            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("NO PORT2");

            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        boolean run = true;
        while (run) {

            if(editText_port.getText().toString().equals("no port") ){
                lock();
                Log.d("thread","sendMulticastMessageToGetPort");
                sendMulticastMessageToGetPort();
            }
            else{
                unlock();
                Log.d("thread","Port Exist");
                state = "port exist";
            }
            SystemClock.sleep(2000);
        }
    }

    public void lock(){
        btnBanana.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
        btnMilk.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
        btnTomato.setBackgroundTintList(ColorStateList.valueOf(Color.RED));

        btnBanana.setClickable(false);
        btnMilk.setClickable(false);
        btnTomato.setClickable(false);
        reserveButtonBanana.setClickable(false);
        reserveButtonMilk.setClickable(false);
        reserveButtonTomato.setClickable(false);

        btnBanana.setText("SEARCHING ..");
        btnMilk.setText(  "SEARCHING ..");
        btnTomato.setText("SEARCHING ..");
    }

    public void unlock(){
        btnBanana.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
        btnMilk.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
        btnTomato.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
        reserveButtonBanana.setClickable(true);
        reserveButtonMilk.setClickable(true);
        reserveButtonTomato.setClickable(true);
    }
}
