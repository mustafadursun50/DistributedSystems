package com.example.clientz;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import static android.widget.Toast.makeText;
import static com.example.clientz.MainActivity.btnBanana;
import static com.example.clientz.MainActivity.btnMilk;
import static com.example.clientz.MainActivity.btnTomato;
import static com.example.clientz.MainActivity.editText_port;

public class TcpClient extends AppCompatActivity {

    // sends message received notifications
    private OnMessageReceived mMessageListener = null;
    // while this is true, the server will continue running
    private boolean mRun = false;
    // used to send messages
    // used to read messages from the server
    private BufferedReader mBufferIn;
    static String lastMessage;
    OutputStream outputStream;
    ObjectOutputStream objectOutputStream;
    ObjectInputStream objectInputStream;
    Socket socket;
    InetAddress serverAddr;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
    }
    public OnMessageReceived getmMessageListener() {
        return mMessageListener;
    }
    /**
     * Constructor of the class. OnMessagedReceived listens for the messages received from server
     */
    public TcpClient(OnMessageReceived listener) {
        mMessageListener = listener;
    }
    /**
     * Sends the message entered by client to the server
     *
     * @param message text entered by client
     */
    public void sendMessage(final String message) {

        Runnable runnable = new Runnable() {

            @Override
            public void run() {

                //here you must put your computer's IP address.
                try {
                    serverAddr = InetAddress.getByName(MainActivity.ipAddress);
                    //create a socket to make the connection with the server
                    socket = new Socket(serverAddr, MainActivity.port);
                    // get the output stream from the socket.
                    outputStream = socket.getOutputStream();
                    // create an object output stream from the output stream so we can send an object through it
                    objectOutputStream = new ObjectOutputStream(outputStream);

                }
                catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    Log.d("TCPMessageFromServer", "CONNECTION FAILED");
                    editText_port.setText("no port");
                    e.printStackTrace();
                }

                if (objectOutputStream != null) {
                    try {
                        objectOutputStream.writeObject(message);
                        Log.d("TCPMessageFromServer", "write: " + message);

                        objectOutputStream.flush();
                        Log.d("TCPMessageFromServer", "flush");

                        objectInputStream = new ObjectInputStream(socket.getInputStream());
                        Log.d("TCPMessageFromServer", "new ObjectInputStream(socket.getInputStream()");

                        String messageFromServer = (String) objectInputStream.readObject();
                        Log.d("TCPMessageFromServer", messageFromServer);

                        String[] state = messageFromServer.split(",");

                        if(messageFromServer.contains("banana,reservation,OK")){
                            Log.d("TCPMessageFromServer", "banana Reservation successful");
                            MainActivity.getApp().startAlert("if you buy "+ state[3] +" you get 3 " + state[4] +" for free", "banana", Integer.parseInt(state[3]));
                        }
                        if(messageFromServer.contains("milk,reservation,OK")){
                            Log.d("TCPMessageFromServer", "milk Reservation successful");
                            MainActivity.getApp().startAlert("if you buy "+ state[3] +" you get 2 " + state[4] +" for free", "milk", Integer.parseInt(state[3]));
                        }

                        if(messageFromServer.contains("tomato,reservation,OK")){
                            Log.d("TCPMessageFromServer", "tomato Reservation successful " + state[3] + "  " + state[4]);
                            MainActivity.getApp().startAlert("if you buy "+ state[3] +" you get 1 " + state[4] +" for free", "tomato", Integer.parseInt(state[3]));
                        }

                        if(messageFromServer.contains("banana,reservation,NOK")){
                            Log.d("TCPMessageFromServer", "banana Reservation failed");
//                            MainActivity.getApp().failedAlert("reservation failed! We have "+ state[3] + " "+ state[0] +" in our store", "bananaFailed", Integer.parseInt(state[3]));

                        }
                        if(messageFromServer.contains("milk,reservation,NOK")){
                            Log.d("TCPMessageFromServer", "milk Reservation failed");
                         //   MainActivity.getApp().failedAlert("reservation failed! We have "+ state[3]  + " "+ state[0] +" in our store", "milkFailed", Integer.parseInt(state[3]));

                        }
                        if(messageFromServer.contains("tomato,reservation,NOK")){
                            Log.d("TCPMessageFromServer", "tomato Reservation failed");
                         //   MainActivity.getApp().failedAlert("reservation failed! We have "+ state[3]  + " "+ state[0] +" in our store", "tomatoFailed", Integer.parseInt(state[3]));
                        }

                        if(messageFromServer.contains("requestOrder,OK")){

                            // requestOrder,OK,banana,3,Gift,tomato,3
                            // req, ok, bana, 3

                            String[] partx = messageFromServer.split(",");


                            if(partx.length == 7){
                                String buyProduct = partx[2];
                                String buyValue = partx[3];
                                String gift = partx[4];
                                String giftProduct = partx[5];
                                String giftValue = partx[6];

                                MainActivity.getApp().failedAlert("if you buy "+ buyValue + " " + buyProduct + " you get " + giftValue + " " + giftProduct +" for free"+ buyProduct);
                            }

                        }



                        if(messageFromServer.contains("responseOrder,OK")){
                            String[] party = messageFromServer.split(",");
                            String buyProduct = party[2];
                            String buyValue = party[3];

                            if(party.length == 7){
                                //responseOrder,OK,banana,8,gift,tomato,3
                                String gift = party[4];
                                String giftProduct = party[5];
                                String giftValue = party[6];
                                MainActivity.getApp().failedAlert("buy succesfull: " + buyValue + " " + buyProduct + " and " + giftValue + " " + giftProduct + " for free!");
                            }

                            else {
                                //responseOrder,OK,banana
                                MainActivity.getApp().failedAlert("buy succesfull: " + buyValue + " " + buyProduct);
                            }
                        }

                        objectOutputStream.close();
                        Log.d("TCPMessageFromServer", "close");

                    }
                    catch (IOException e) {
                        CheckPort udpMessage = new CheckPort();
                        udpMessage.sendMulticastMessageToGetPort();
                        Log.d("TCPMessageFromServer", "LEADER CHANGE GET PORT");
                        // send multicast message
                        e.printStackTrace();
                    }
                    catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        Thread thread = new Thread(runnable);
        thread.start();
    }

    //Declare the interface. The method messageReceived(String message) will must be implemented in the Activity
    //class at on AsyncTask doInBackground
    public interface OnMessageReceived {
        public void messageReceived(String message);
    }
}