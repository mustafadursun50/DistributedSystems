package com.example.clientz;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    public static Button btnBanana, btnMilk, btnTomato, btnServerSeqID, btnClientSeqID, btnMessage, reserveButtonBanana, reserveButtonMilk, reserveButtonTomato;
    public static EditText editText_ip, editText_port, editText_mes;
    TcpClient mTcpClient;
    static String ipAddress;
    static int port;
    static int valuePopup;
    static boolean reserve = false;
    static int buyOrder;
    AlertDialog alertDialog, alertDialog2;

    private static Context context; //application context
    private Handler mainThreadHandlerx;


    public class ConnectTask extends AsyncTask<String, String, UDPMulticastSocket> {
        @Override
        protected UDPMulticastSocket doInBackground(String... message) {

            mTcpClient = new TcpClient(new TcpClient.OnMessageReceived() {

                @Override
                //here the messageReceived method is implemented
                public void messageReceived(String message) {
                    //this method calls the onProgressUpdate
                    publishProgress(message);
                }
            });
            return null;
        }
    }

    public static MainActivity getApp(){
        return (MainActivity) context;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;

        initialize();
        startThreadToCheckPort();
        startThread();

        /////////////////////////////////////// Button Click


        reserveButtonBanana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupToSend("btnBananaReserve");
                reserve = false;
            }
        });

        reserveButtonMilk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupToSend("btnMilkReserve");
                reserve = false;
            }
        });

        reserveButtonTomato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupToSend("btnTomatoReserve");
                reserve = false;
            }
        });
    }

    public void popupToSend(String btn){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("How much ?");

        // Set up the input
        final EditText input = new EditText(this);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        builder.setView(input);
        builder.setCancelable(false);
        // Set up the buttons
        builder.setPositiveButton("RESERVE", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                valuePopup = Integer.parseInt(input.getText().toString());


                if(btn=="btnBananaReserve"){
                    buyOrder = valuePopup;
                    sendTcpMessage("reserve,"+ valuePopup+",0,0,"+ Instant.now() );
                }
                if(btn=="btnMilkReserve"){
                    buyOrder = valuePopup;
                    sendTcpMessage("reserve,0,"+ valuePopup+",0,"+Instant.now());
                }
                if(btn=="btnTomatoReserve"){
                    buyOrder = valuePopup;
                    sendTcpMessage("reserve,0,0,"+ valuePopup+","+Instant.now());
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    public void sendTcpMessage(String message){

        ipAddress = editText_ip.getText().toString();
        port      = Integer.valueOf(editText_port.getText().toString());
        new ConnectTask().execute();
        SystemClock.sleep(50);

        if (mTcpClient != null) {
            mTcpClient.sendMessage(message);
            SystemClock.sleep(50);
        }
    }

    public void initialize(){
        editText_ip         = findViewById(R.id.ipaddress);
        editText_port       = findViewById(R.id.port);
        editText_mes        = findViewById(R.id.message);
        btnBanana           = findViewById(R.id.btnBanana);
        btnMilk             = findViewById(R.id.btnMilk);
        btnTomato           = findViewById(R.id.btnTomato);
        btnServerSeqID      = findViewById(R.id.btnServerSeqId);
        btnClientSeqID      = findViewById(R.id.btnClientSeqId);
        btnMessage          = findViewById(R.id.btnMessage);
        reserveButtonBanana = findViewById(R.id.reserveButtonBanana);
        reserveButtonMilk   = findViewById(R.id.reserveButtonMilk);
        reserveButtonTomato = findViewById(R.id.reserveButtonTomato);
    }

    public void startThread(){
        Thread thread = new Thread() {

            @Override
            public void run() {
                try {
                    new UDPMulticastSocket().run();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();
    }

    public void startThreadToCheckPort(){
        Thread thread = new Thread() {

            @Override
            public void run() {
                try {
                    new CheckPort().run();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();
    }

    public Handler getMainThreadHandler() {
        if (mainThreadHandlerx == null) {
            mainThreadHandlerx = new Handler(Looper.getMainLooper());
        }
        return mainThreadHandlerx;
    }

    public void startAlert(final String message, final String product, final int value) {

        getMainThreadHandler().post(new Runnable() {
            @Override
            public void run() {
                alertDialog = new AlertDialog.Builder(context).setTitle(message).setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //set what would happen when positive button is clicked
                                Toast.makeText(getApplicationContext(),"send buy more message succesfully",Toast.LENGTH_LONG).show();


                                // requestOrder,3,0,3
                                if(product=="banana"){
                                    sendTcpMessage("requestOrder,"+value+",0,0,"+Instant.now());
                                }
                                if(product=="milk"){
                                    sendTcpMessage("requestOrder,0,"+value+",0,"+Instant.now());
                                }
                                if(product=="tomato"){
                                    sendTcpMessage("requestOrder,0,0,"+value+","+Instant.now());
                                }
                            }
                        })
                        .setNegativeButton("No thats enough", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //set what should happen when ith enough button is clicked
                                // requestOrder,3,0,0


                                if(product=="banana"){
                                    sendTcpMessage("requestOrder,"+(value-3)+",0,0,"+Instant.now());
                                    Toast.makeText(getApplicationContext(),"requestOrder,"+(value-3)+",0,0",Toast.LENGTH_LONG).show();

                                }
                                if(product=="milk"){
                                    sendTcpMessage("requestOrder,0,"+(value-2)+",0,"+Instant.now());
                                    Toast.makeText(getApplicationContext(),"requestOrder,0,"+(value-2)+",0",Toast.LENGTH_LONG).show();

                                }
                                if(product=="tomato"){
                                    sendTcpMessage("requestOrder,0,0," + (value-1)+","+Instant.now());
                                    Toast.makeText(getApplicationContext(),"requestOrder,0,0," + (value-1),Toast.LENGTH_LONG).show();

                                }
                            }
                        })
                        .show();

                new CountDownTimer(9800, 1000) {

                    @Override
                    public void onTick(long millisUntilFinished) {
                        // TODO Auto-generated method stub

                    }

                    @Override
                    public void onFinish() {
                        // TODO Auto-generated method stub

                        alertDialog.dismiss();
                    }
                }.start();
            }
        });
        }

    public void failedAlert(final String message) {
        getMainThreadHandler().post(new Runnable() {
            @Override
            public void run() {
                alertDialog2 = new AlertDialog.Builder(context).setTitle(message).setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {}
                        }).show();

            }
        });
    }
}
