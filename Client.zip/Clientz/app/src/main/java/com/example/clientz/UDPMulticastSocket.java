package com.example.clientz;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.Log;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;


public class UDPMulticastSocket extends MainActivity implements Runnable  {

    // Netzwerk-Gruppe
    String NETWORK_GROUP = "230.0.0.1";
    // Netzwerk-Gruppen Port
    int NETWORK_GROUP_PORT = 4447;
    // Nachrichten-Codierung
    String TEXT_ENCODING = "UTF8";
    // Counter Multicast ID
    int cID = 0;
    int sID = 0;
    int serverSeqID ;

    InetAddress group;
    java.net.MulticastSocket socket;


    @Override
    public void run() {
        boolean run = true;

        while (run) {
            try {

                // Gruppe anlegen
                group = InetAddress.getByName(NETWORK_GROUP);
                socket = new MulticastSocket(NETWORK_GROUP_PORT);

                // Gruppe beitreten
                socket.joinGroup(group);

                byte[] message = new byte[200];

                DatagramPacket packet = new DatagramPacket(message,message.length);
                socket.receive(packet);
                String messageFromServer = new String(packet.getData(), 0, packet.getLength(), TEXT_ENCODING);
                Log.d("messageFromServer",messageFromServer);
                btnMessage.setText("FROM SERVER: " +messageFromServer);

                String[] parts = messageFromServer.split(",");

                Log.d("fromServer",messageFromServer);


                if(parts.length == 5){

                    editText_ip.setText(packet.getAddress().toString().replaceAll("/",""));    // IP
                    editText_port.setText( parts[0] );                                                          // Port
                    btnBanana.setText(     parts[1] );                                                          // Banana
                    btnMilk.setText(       parts[2] );                                                          // Milk
                    btnTomato.setText(     parts[3] );                                                          // Tomato
                    btnServerSeqID.setText("ServerSeqID = " + parts[4]);                                        // ServerSeqID
                    serverSeqID = Integer.parseInt(parts[4]);
                    Log.d("fromx1",parts[0]);
                    Log.d("fromx1",parts[1]);
                    Log.d("fromx1",parts[2]);
                    Log.d("fromx1",parts[3]);
                    Log.d("fromx1",parts[4]);

                }

                if(parts.length == 4){
                    btnBanana.setText(parts[0] );                                                          // Banana
                    btnMilk.setText(parts[1] );                                                          // Milk
                    btnTomato.setText(parts[2] );                                                          // Tomato
                    btnServerSeqID.setText("ServerSeqID = " + parts[3]);                                        // ServerSeqID
                    //btnClientSeqID.setText("ClientSeqID = " + parts[3]);
                    Log.d("fromx2",parts[0]);
                    Log.d("fromx2",parts[1]);
                    Log.d("fromx2",parts[2]);
                    Log.d("fromx2",parts[3]);

                }

                cID = Integer.parseInt(btnClientSeqID.getText().toString().substring(14));
                sID = Integer.parseInt(btnServerSeqID.getText().toString().substring(14));


                if (cID == 0){
                    cID = sID ;
                    btnClientSeqID.setText("ClientSeqID = " + cID);
                }

                Log.d("Get Message","server vorher = "+ sID);
                Log.d("Get Message","client vorher = "+ cID);

                if(cID != sID){
                    btnClientSeqID.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                    Log.d("Get Message","packageLoss");

                    sendTcpMessage("packageLoss," + cID);
                    //SystemClock.sleep(2000);
                    cID = cID + 1;

                    Log.d("Get Message","s nachher = "+ sID);
                    Log.d("Get Message","c nachher = "+ cID);

                    btnClientSeqID.setText("ClientSeqID = " + cID);
                    btnClientSeqID.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                }



                btnServerSeqID.setBackgroundTintList(ColorStateList.valueOf(Color.YELLOW));
                btnClientSeqID.setBackgroundTintList(ColorStateList.valueOf(Color.YELLOW));
                btnBanana.setBackgroundTintList(ColorStateList.valueOf(Color.YELLOW));
                btnMilk.setBackgroundTintList(ColorStateList.valueOf(Color.YELLOW));
                btnTomato.setBackgroundTintList(ColorStateList.valueOf(Color.YELLOW));

            }
            catch (IOException e) {
                Log.e("UDP client has IOException", "error: ", e);
                run = false;
            }
        }
    }
}